﻿using System;
using System.Data;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter the first number:");
        if (!double.TryParse(Console.ReadLine(), out double num1))
        {
            Console.WriteLine("Invalid input for the first number.");
            return;
        }

        Console.WriteLine("Enter the second number:");
        if (!double.TryParse(Console.ReadLine(), out double num2))
        {
            Console.WriteLine("Invalid input for the second number.");
            return;
        }

        Console.WriteLine("Enter the mathematical operation (+, -, *, /):");
        string operation = Console.ReadLine();

        double result = MegoldottEgyenletek(num1, num2, operation);

        if (double.IsNaN(result))
        {
            Console.WriteLine("Invalid mathematical operation.");
        }
        else
        {
            Console.WriteLine("Result: " + result);
        }
    }

    public static double MegoldottEgyenletek(double num1, double num2, string operation)
    {
        switch (operation)
        {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "*":
                return num1 * num2;
            case "/":
                if (num2 == 0)
                {
                    return double.NaN;
                }
                return num1 / num2;
            default:
                return double.NaN; 
        }
    }
}
