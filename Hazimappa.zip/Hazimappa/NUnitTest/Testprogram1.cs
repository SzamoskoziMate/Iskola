﻿namespace NUnitTestProject;


public class Testprogram1
{
    [OneTimeSetUp]
    public void OneTimeSetup()
    {
    }
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void SimpleTest()
    {
        Assert.Pass();
    }
    [Test]
    [TestCase(1,1,"2")]
    [TestCase(2,2,"4")]
    public void TestWithTestCases(int szam1, int szam2, string eredmeny)
    {
      
        Assert.That((szam1 + szam2).ToString(), Is.EqualTo(eredmeny));
        Assert.That((szam1 % szam2).ToString(), Is.EqualTo(eredmeny));
    }
    [TearDown]
    public void TearDown()
    {
    }
    [OneTimeTearDown]
    public void OneTimeTearDown()
    {
    }
}
