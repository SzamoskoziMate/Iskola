﻿namespace Class_Library{
    public static class Szamologep
    {
        public static double MegoldottEgyenletek(double num1, double num2, string operation)
        {
            switch (operation)
            {
                case "+":
                    return num1 + num2;
                case "-":
                    return num1 - num2;
                case "*":
                    return num1 * num2;
                case "/":
                    if (num2 == 0)
                    {
                        return double.NaN; // Handle division by zero as NaN
                    }
                    return num1 / num2;
                default:
                    return double.NaN; // Handle invalid operation as NaN
            }
        }
    }
}
